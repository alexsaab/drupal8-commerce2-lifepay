<?php

namespace Drupal\commerce_lifepay\Plugin\Commerce\PaymentGateway;

use Drupal\commerce_payment\Plugin\Commerce\PaymentGateway\OffsitePaymentGatewayInterface;

interface LifepayPaymentInterface extends OffsitePaymentGatewayInterface
{

}